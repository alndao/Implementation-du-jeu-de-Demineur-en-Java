import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.Timer;


public class Demineur extends JFrame implements MouseListener 
{
	private JPanel p;
	private Grille grille;
	private int hauteur;
	private int largeur;
	private int pourcentage;
	private boolean fini;
	private boolean gagne;
	private boolean isTimerRunning = false;
	private int elapsedSeconds = 0;

	public Demineur(int h, int l, int pourcent)
	{
        // définit le titre de la fenêtre
        super("Demineur");
		
		this.hauteur = h;
		this.largeur =  l;
		this.pourcentage = pourcent;

		setLayout (new BorderLayout());
		p = new JPanel( new GridLayout(hauteur,largeur,0,0));
		p.setBackground (Color.LIGHT_GRAY);
		p.setBorder (BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK));
        
		grille = new Grille(hauteur,hauteur,10);
		grille.initGrille();
	}

	public void paint()
	{	
		// Le menu de la fenetre			
		JMenuBar menuBar = new JMenuBar();
		menuBar.setPreferredSize(new Dimension(getWidth(), 40));

        JMenu menuNiveau = new JMenu("Niveau");

		menuBar.add(Box.createRigidArea(new Dimension(190, 0)));
        menuBar.setBackground(Color.GREEN);
		JMenuItem item1 = new JMenuItem("Facile");
		
		item1.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
				p.removeAll();
				Demineur facile = new Demineur(12, 12, 10);
				facile.paint();
			}
		});

        JMenuItem item2 = new JMenuItem("Moyen");

		item2.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
      			p.removeAll();
				Demineur facile = new Demineur(15, 15, 15);
				facile.paint();
    		}
		});

		JMenuItem item3 = new JMenuItem("Difficile");
		item3.addActionListener(new ActionListener() {
    		public void actionPerformed(ActionEvent e) {
      			p.removeAll();
				Demineur facile = new Demineur(20, 20, 30);
				facile.paint();
    		}
		});

		ImageIcon icone = new ImageIcon("images/horloge.jpeg");
		Image imge = icone.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		icone = new ImageIcon(imge);
		JLabel timeLabel = new JLabel("Temps : " + String.valueOf(this.elapsedSeconds), icone, JLabel.LEFT);
		//JLabel timeLabel = new JLabel("Temps : 0");
		menuBar.add(timeLabel);		
		// Initialisation du chronomètre
		Timer timer = new Timer(1000, new ActionListener() {
    		//private int elapsedSeconds = 0;
    		public void actionPerformed(ActionEvent e) {				
				elapsedSeconds = elapsedSeconds + 1 ;
        		timeLabel.setText("Temps : " + elapsedSeconds);
	    	}
		});
		
		timer.start();
	 
		// Ajouter les éléments au menu et à la barre de menu
        menuNiveau.add(item1);
		menuNiveau.add(new JSeparator());
        menuNiveau.add(item2);
		menuNiveau.add(new JSeparator());
		menuNiveau.add(item3);

        menuBar.add(menuNiveau);

        // Ajouter la barre de menu en haut de la fenêtre
        this.setJMenuBar(menuBar);

		menuBar.add(Box.createRigidArea(new Dimension(200, 0))); // Ajout d'un espace de 10 pixels entre les éléments
		
		if (this.fini && this.gagne)
		{
			this.getContentPane().removeAll();
			JLabel label = new JLabel("FELICITATIONS !!!");
            setPreferredSize(new Dimension(500, 500));
			label.setHorizontalAlignment(JLabel.CENTER);
			label.setVerticalAlignment(JLabel.CENTER);
			p.setLayout(new BorderLayout());
			p.add(label, BorderLayout.CENTER); 
      	}

		else {

			for (int i = 0; i < this.hauteur; i++)
			{
				for (int j = 0; j < this.largeur; j++)
				{
					if (!grille.parcours(i, j).getEstDecouvert() && !grille.parcours(i, j).getEstMarque())
					{
						JButton bouton = new JButton();
						bouton.setBackground(new Color(0,128,0)); // vert foncé
						bouton.addMouseListener(this);
						bouton.setPreferredSize(new Dimension(45, 45));
						this.p.add(bouton);
					}
					else if (grille.parcours(i, j).getEstMarque())
					{
						JButton bouton = new JButton();
						bouton.setBackground(Color.GRAY);
						bouton.setPreferredSize(new Dimension(45, 45));
						bouton.addMouseListener(this);
						ImageIcon icon = new ImageIcon("images/image.jpg");
    	    			// Redimensionnement de l'image
        				Image img = icon.getImage();
        				Image newImg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
	   				   	icon = new ImageIcon(newImg);

    			    	// Attribution de l'image au bouton
	    			    bouton.setIcon(icon);
						this.p.add(bouton);				
					}
					else 
					{
						if (grille.parcours(i,j).getEstMine())
        	            {
							JButton bouton = new JButton();
							bouton.setBackground(new Color(144, 238, 144));
							bouton.setPreferredSize(new Dimension(45, 45));
							bouton.addMouseListener(this);
							ImageIcon icon = new ImageIcon("images/bombe.png");
        					// Redimensionnement de l'image
        					Image img = icon.getImage();
	        				Image newImg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		   				   	icon = new ImageIcon(newImg);
	
    					    // Attribution de l'image au bouton
    					    bouton.setIcon(icon);
							this.p.add(bouton);	
            	        }


						else if (grille.parcours(i,j).getNbMines() == 0)
						{
						
							JButton bouton = new JButton();
							bouton.setBackground(new Color(144, 238, 144));
							bouton.setPreferredSize(new Dimension(45, 45));
							bouton.addMouseListener(this);
							this.p.add(bouton);
						}	
						else if (grille.parcours(i,j).getNbMines() > 0)
						{
							JButton bouton = new JButton(String.valueOf(grille.parcours(i,j).getNbMines()));
							bouton.setFont(new Font("Arial", Font.PLAIN, 18));
							switch (grille.parcours(i,j).getNbMines())
							{
							    case (1):
							        bouton.setForeground(Color.BLUE.darker().darker()); 
							        break;
							    case (2):
							        bouton.setForeground(Color.RED.darker().darker());
						    	    break;
							    case (3):
						    	    bouton.setForeground(Color.BLACK.darker().darker()); 
						        	break;
							    case (4):
    						    	bouton.setForeground(Color.GRAY.darker().darker()); 
        							break;
	    						case (5):
    	    						bouton.setForeground(Color.MAGENTA.darker().darker());
       			 					break;
  					 		 	case (6):
    	    						bouton.setForeground(Color.ORANGE.darker().darker());
        							break;
							    case (7):
						   	    	bouton.setForeground(Color.WHITE.darker().darker());
    							    break;
						    	case (8):
    						    	bouton.setForeground(Color.PINK.darker().darker()); 
 							       break;
							}

							bouton.setBackground(new Color(144, 238, 144));
							bouton.setPreferredSize(new Dimension(45, 45));
							bouton.addMouseListener(this);
							this.p.add(bouton);
						}	
					}
				}
			}
		}
		getContentPane().add(p);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void aGagne()
    {
        int nbBombe = 0;
        int nbNonDecouvert = 0;

        for (int i = 0; i < this.grille.getHauteur(); i++)
        {
            for (int j = 0; j < this.grille.getLargeur(); j++)
            {
                if (this.grille.parcours(i, j).getEstMine())

                        nbBombe++;

                if (!this.grille.parcours(i, j).getEstDecouvert())

                        nbNonDecouvert++;
            }
        }

        if (nbBombe == nbNonDecouvert)
        {
            this.fini = true;
            this.gagne = true;
        }
    }

	public void aPerdu()
    {
        for (int i = 0; i < this.hauteur; i++)
        {
            for (int j = 0; j < this.largeur; j++)
            {
                if (this.grille.parcours(i, j).getEstMine() && this.grille.parcours(i,j).getEstDecouvert())
                {
                    this.fini = true;
                    this.gagne = false;
                }

            }
        }
    }

	@Override
    public void mouseClicked(MouseEvent e)
	{
		// on recupere les coordonnées de la case cliquée
		
		Component b =  (Component) e.getSource();
		Point point = b.getLocation();
				
		int x = point.y / 45; 
		int y = point.x / 45; 		
			
		if (this.hauteur > x && this.largeur > y);
		{
			if (e.getButton() == 1)
			{
				if (!this.grille.parcours(x, y).getEstDecouvert() && !this.fini)
				{
					this.grille.parcours(x, y).uncover();
				}
			}
			
			if (e.getButton() == 3)
			{
				if (!this.grille.parcours(x,y).getEstDecouvert() && !this.fini)
				{
					this.grille.parcours(x, y).setEstMarque(true);
				}
			}
		}	

		// On vérifie si la partie n'est pas encore finie

		this.aPerdu();
		this.aGagne();

		if (this.getFini())
        {  
      	  if (this.getGagne())
          {
               this.fini = true;
          }
          else  // sinon la partie est perdue on affiche les bombes
          {
          	for (int i = 0; i < this.getGrille().getHauteur(); i++)
            {
            	for (int j = 0; j < this.getGrille().getLargeur(); j++)
                {
                	if (this.getGrille().parcours(i, j).getEstMine())
                    {
                    	this.getGrille().parcours(i, j).setEstDecouvert(true);			
                    }
                }
             }
          }    
		}

		p.removeAll();
		this.paint();
    }

	public void mouseEntered(MouseEvent e) {
        // La souris est entrée dans la zone du bouton.
    }

    public void mouseExited(MouseEvent e) {
        // La souris est sortie de la zone du bouton.
    }

    public void mousePressed(MouseEvent e) {
        // La souris est appuyée sur le bouton.
    }

    public void mouseReleased(MouseEvent e) {
        // La souris est relâchée sur le bouton.
    }

	public boolean getFini()
    {
        return this.fini;
    }

    public void setFini(boolean bool)
    {
        this.fini = bool;
    }


    public boolean getGagne()
    {
        return this.gagne;
    }

    public Grille getGrille()
    {
        return this.grille;
    }	

	public static void main(String[] args) 
	{
        Demineur demineur = new Demineur(12, 12, 13);
		demineur.paint();
			
    }

}
