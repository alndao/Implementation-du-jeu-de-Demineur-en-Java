import java.io.*;
import java.util.Random;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main
{
	public static void main(String[] agrs)
	{	
			
		String hauteurStr;
		String largeurStr;
		String pourcentageBombeStr;
		
		System.out.println("\nBIENVENU\n");

		System.out.println("Choissez les dimensions de la grille et le poucentage de Bombes: ");
		System.out.print("Hauteur = ");
		hauteurStr = System.console().readLine();
		System.out.print("Largeur = ");
		largeurStr = System.console().readLine();
		System.out.print("Pourcentage = ");
		pourcentageBombeStr = System.console().readLine();


		int hauteur = Integer.parseInt(hauteurStr); 	
		int largeur = Integer.parseInt(largeurStr); 	
		int pourcentage = Integer.parseInt(pourcentageBombeStr); 	

		Jouer jeu = new Jouer(hauteur, largeur, pourcentage);

		System.out.println("\nDEBUT LA PARTIE");
		
		String coordXStr;
		String coordYStr;
		String choixStr;
	
		int coordX;
		int coordY;
		int choix;
		
		jeu.getGrille().afficher();
		
		while (!jeu.getFini())
		{
			// je lui demande de choisir une case	
			System.out.println("Choisser une case : X Y");
			System.out.print("X = ");
			coordXStr = System.console().readLine();
			System.out.print("Y = ");
			coordYStr = System.console().readLine();
		
			coordX = Integer.parseInt(coordXStr); 	
			coordY = Integer.parseInt(coordYStr);

			// je lui demande quelle action il veut effectuer
			
			System.out.print("\n[1]decouvrir [2]marquer [3]quitter [4]sauvegarder : ");	
			choixStr = System.console().readLine();
			
			choix = Integer.parseInt(choixStr); 
	
			if (choix == 3)
			{
				jeu.setFini(true);
			}	
			//Partie sauvegarde
			else if (choix == 4)
			{
				Path path = Paths.get("saveGrille.txt");
				try
				{
					jeu.getGrille().save(path);	
					System.out.println("/*******************************************/");
					System.out.println("\n/**          Partie Sauvegardée           **/\n");
					System.out.println("/*******************************************/");
				} 
				catch (IOException e)
				{
					System.out.println("Chemin du fichier incorrect");
				}
			}

			// on effetue l'action
			jeu.jouerPartie(choix, coordX, coordY);
		
			jeu.getGrille().afficher();

			// Vérifions si la partie est encore actuelle		
			if (jeu.getFini())
			{
				if (choix == 3)
				{
					System.out.println("Dommage ! Vous avez quitté la partie");
				}
				else if (jeu.getGagne())
				{
					System.out.println("Vous avez gagné la partie.");
				}
				else  // sinon la partie est perdue on affiche les bombes 
				{
					for (int i = 0; i < jeu.getGrille().getHauteur(); i++)
					{
						for (int j = 0; j < jeu.getGrille().getLargeur(); j++)
						{
							if (jeu.getGrille().parcours(i, j).getEstMine())
							{
								jeu.getGrille().parcours(i, j).setEstDecouvert(true);
							}
						}
					}
					jeu.getGrille().afficher();
					System.out.println("Vous avez perdu la partie.");
				}
			}	
		}
	}
}
