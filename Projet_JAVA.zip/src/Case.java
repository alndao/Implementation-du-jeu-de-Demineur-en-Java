import java.util.Map;
import java.util.EnumMap;

public class Case
{
		private EnumMap<Direction, Case> caseVoisines;
		private int nbMines;
	   	private boolean estMine;
		private boolean estMarque;	
		private boolean estDecouvert;
			
		public Case(boolean bool)
		{
			this.estMine = bool;
			this.caseVoisines = new EnumMap<>(Direction.class);
			
		}

		// ajouter un voisine à la case
		void ajouterVoisine(Direction direction, Case c)
		{
			caseVoisines.put(direction, c);
		}

		public EnumMap<Direction, Case> getCaseVoisines() 
		{
			return this.caseVoisines;
		}

		// compter le nombre de mines dans les cases voisines

		public int compteMine()
		{
			int compteur = 0;

			for (Map.Entry<Direction, Case> entry : this.caseVoisines.entrySet()) 
			{
     			Case value = entry.getValue();

				if (value.estMine)
				{
					compteur++; 
				}
			}

			return compteur;
		}

		
		public void uncover()
		{
			this.estDecouvert = true;

			if (!this.getEstMine() && this.getNbMines() == 0)
			{
				for (Map.Entry<Direction, Case> entry : this.caseVoisines.entrySet())
            	{
                	Case value = entry.getValue();
				
					if (value.getEstDecouvert() == false && value.getEstMine() == false)
					{
						if (value.getNbMines() > 0)
						{
							value.setEstDecouvert(true);
						}
						else
						{
							value.uncover();
						}
					}			  
        	    }
			}	
		}

		// les getteurs et setteurs

		public int getNbMines()
		{
			this.nbMines = this.compteMine();

			return this.nbMines;
		}
		public void setNbMines(int n)
		{
			this.nbMines = n;
		}

		public boolean getEstMine()
		{
			return this.estMine;
		}
		public void setEstMine(boolean bool)
		{
			this.estMine = bool;
		}

		public boolean getEstMarque()
		{
			return this.estMarque;
		}
		public void setEstMarque(boolean bool)
		{
			this.estMarque = bool;
		}

		public boolean getEstDecouvert()
		{
			return this.estDecouvert;
		}
		public void setEstDecouvert(boolean bool)
		{
			this.estDecouvert = bool;
		}
}
