import java.util.Random;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.nio.charset.StandardCharsets;


public class Grille
{
	private int hauteur;
	private int largeur;
	private int pourcentage;
	private Case caseInit;

	public Grille(int h, int l, int p)
	{
		this.hauteur = h;
		this.largeur = l;
		this.caseInit = new Case(false);
		this.pourcentage = p;
		
		Random rand = new Random();
		if (rand.nextInt(100) < this.pourcentage)
		{	
			caseInit.setEstMine(true);	
		}

	}

	// elle renvoie la case se situe à l'indice x, y
	public Case parcours(int x, int y)
	{
		Case precedent = caseInit;

		for (int i = 0; i < x; i++)
		{
			precedent = precedent.getCaseVoisines().get(Direction.BAS);
		}

		for (int j = 0; j < y; j++)
		{
			precedent = precedent.getCaseVoisines().get(Direction.DROITE);
		}

		return precedent;
	}

	// afficher une ligne de la grille
	private void afficherLigne(Case c, int numLigne)
	{
		Case precedent = c;
		
		if (numLigne < 10)
		{	
			System.out.print(numLigne + "  ");
		}
		else
		{
			System.out.print(numLigne + " ");
		}

		while (precedent.getCaseVoisines().get(Direction.DROITE) != null)
		{
			if (!precedent.getEstMarque() && !precedent.getEstDecouvert())
			{
				System.out.print("\u001B[46m" + "  " + "\u25A0" + " |" + "\u001B[0m");
			}
			else if (precedent.getEstMarque())
			{
				System.out.print("\u001B[46m"  + "  " +  "\u001B[31m"+ "\u2691" + " |" + "\u001B[0m");
	
			}
			else 
			{
				if (precedent.getNbMines() == 0 && precedent.getEstMine() == false)
				{
					System.out.print("\u001B[46m"  + "  " + " "+ " |" + "\u001B[0m");
				}
				else if (precedent.getNbMines() > 0 && precedent.getEstMine() == false)
				{	
					System.out.print("\u001B[46m"  + "  " + precedent.getNbMines() + " |" + "\u001B[0m");
				}				
				else if (precedent.getEstMine())
				{
					System.out.print("\u001B[46m"  + "  " + "\u001B[31m" + "*"+ " |" + "\u001B[0m");
				}
			}			
			precedent = precedent.getCaseVoisines().get(Direction.DROITE);
		}

		System.out.println();
	}

	// afficher la grille
	public void afficher()
	{
		Case precedent = caseInit;

		System.out.println("\n");	
		
		System.out.print("   ");

		for (int i = 0; i < this.largeur; i++)
		{
			if (i < 10)
			{	
				System.out.print("  " + i + "  ");
			}
			else
			{
				System.out.print(" " + i + "  ");
			}
		}

		System.out.println("\n");

		int numLigne = 0;

		while (precedent.getCaseVoisines().get(Direction.BAS) != null)
		{
			afficherLigne(precedent, numLigne);
			numLigne++;
			precedent = precedent.getCaseVoisines().get(Direction.BAS);
		}	
		System.out.println("\n");
	}


	// faire les liens diagonaux
	private void relierDiagonale(Case c)
	{
		if (c.getCaseVoisines().get(Direction.HAUT) != null)
		{
			if (c.getCaseVoisines().get(Direction.HAUT).getCaseVoisines().get(Direction.DROITE) != null)
			{
				c.ajouterVoisine(Direction.HAUTDROITE, c.getCaseVoisines().get(Direction.HAUT).getCaseVoisines().get(Direction.DROITE));
				c.getCaseVoisines().get(Direction.HAUT).getCaseVoisines().get(Direction.DROITE).ajouterVoisine(Direction.BASGAUCHE, c);
			}
		}
		
		if (c.getCaseVoisines().get(Direction.HAUTDROITE) != null)
		{
			if (c.getCaseVoisines().get(Direction.DROITE) != null)
			{		
				c.getCaseVoisines().get(Direction.HAUTDROITE).ajouterVoisine(Direction.BAS, c.getCaseVoisines().get(Direction.DROITE));
				c.getCaseVoisines().get(Direction.DROITE).ajouterVoisine(Direction.HAUT, c.getCaseVoisines().get(Direction.HAUTDROITE));
			}
		}

		if (c.getCaseVoisines().get(Direction.HAUT) != null)
		{
			if (c.getCaseVoisines().get(Direction.DROITE) != null)
			{
				c.getCaseVoisines().get(Direction.HAUT).ajouterVoisine(Direction.BASDROITE, c.getCaseVoisines().get(Direction.DROITE));
			    c.getCaseVoisines().get(Direction.DROITE).ajouterVoisine(Direction.HAUTGAUCHE, c.getCaseVoisines().get(Direction.HAUT));	
			}
		}	
	}

	
	// creer une ligne
	
	private Case creerLigne(int nbElem, int numLigne)
	{
		Random rand = new Random();

		Case caseRef = new Case(false);
		Case precedent = caseRef;

		for (int i = 1; i <= nbElem; i++)
		{
			Case c = new Case(false);
			
			if (rand.nextInt(100) < this.pourcentage && numLigne != hauteur - 1 && i < nbElem)
			{	
				c.setEstMine(true);	
			}
			precedent.ajouterVoisine(Direction.DROITE, c);
			
			c.ajouterVoisine(Direction.GAUCHE, precedent);

			precedent = c;
		}
		return caseRef;
	}

	// initialiser la grille
	public Case initGrille()
	{
		Random rand = new Random();

		caseInit = creerLigne(largeur, 0);

		Case precedent = caseInit;

		for (int i = 0; i < hauteur; i++)
		{
			Case c = creerLigne(largeur, i);
		
			if (rand.nextInt(100) < this.pourcentage && i != hauteur - 1 )
			{
				c.setEstMine(true);
 			}
			
			precedent.ajouterVoisine(Direction.BAS, c);
			c.ajouterVoisine(Direction.HAUT, precedent);
			
			precedent = c;

			while (c != null)
			{
				relierDiagonale(c);

				c = c.getCaseVoisines().get(Direction.DROITE); 
			}
		}

		for (int i = 0; i < largeur; i++)
		{
			parcours(hauteur - 1, i).setEstMine(false);
		}
		return caseInit;	
	}

	// Sauvegarder l'etat de la grille
	public void save(Path path) throws IOException 
	{
		try
		{
			String chaine;
			chaine = "";
			Files.write(path, chaine.getBytes());

			for (int i = 0; i < this.getHauteur(); i++) 
			{
            	for (int j = 0; j < this.getLargeur(); j++) 
				{
            		if (!this.parcours(i, j).getEstMarque() && !this.parcours(i, j).getEstDecouvert())
					{
						chaine = "*";
						Files.write(path, chaine.getBytes(), java.nio.file.StandardOpenOption.APPEND);
					}
					else if (this.parcours(i, j).getEstMarque())
					{
						chaine =  "m";
						Files.write(path, chaine.getBytes(), java.nio.file.StandardOpenOption.APPEND);
					}
					else 
					{	
						if (this.parcours(i, j).getNbMines() == 0 && this.parcours(i, j).getEstMine() == false)
						{
							chaine = " ";
							Files.write(path, chaine.getBytes(), java.nio.file.StandardOpenOption.APPEND);
						}
						else if (this.parcours(i, j).getNbMines() > 0 && this.parcours(i, j).getEstMine() == false)
						{	
							chaine = String.valueOf(this.parcours(i, j).getNbMines());
							Files.write(path, chaine.getBytes(), java.nio.file.StandardOpenOption.APPEND);
						}
						else if (this.parcours(i, j).getEstMine()) // initule car si la perdue est perdue on ne peut
						{										   // plus la sauvegarder
							chaine = "+";
							Files.write(path, chaine.getBytes(), java.nio.file.StandardOpenOption.APPEND);
						}
					}
				}
				chaine = "\n";
				Files.write(path, chaine.getBytes(), java.nio.file.StandardOpenOption.APPEND);
			}
		} 
		catch (IOException e) 
		{
			System.out.println("Erreur sur le chemin du fichier");
		}
	}

	// recharger la l'etat
	public Grille load(Path path) throws IOException 
	{
		try
		{
			int hauteur;
			int largeur;
			List<String> lignes = Files.readAllLines(path);	
			hauteur = lignes.size();
			largeur = lignes.get(0).length();
			
			Grille grilleLoad = new Grille(hauteur, largeur, 0); // on crée d'abdord une de meme taille grille sans bombe
			grilleLoad.initGrille();
					
			// on modifie notre grille pour quelle corresponde à celle lue
			for(int i = 0; i < hauteur; i++)
			{
				for (int j = 0; j < largeur; j++)
				{
					if (Character.isDigit(lignes.get(i).charAt(i)))
					{
						grilleLoad.parcours(i, j).setEstDecouvert(true);
						grilleLoad.parcours(i, j).setEstMine(false);
						grilleLoad.parcours(i, j).setEstMarque(false);
					}
					else
					{
						if (lignes.get(i).charAt(i) == '*')
						{
							grilleLoad.parcours(i, j).setEstDecouvert(false);
							grilleLoad.parcours(i, j).setEstMarque(false);
						}
						else if (lignes.get(i).charAt(i) == ' ')
						{
							grilleLoad.parcours(i, j).setEstDecouvert(true);
							grilleLoad.parcours(i, j).setEstMine(false);
							grilleLoad.parcours(i, j).setEstMarque(false);
						}
						else if (lignes.get(i).charAt(i) == 'm')
						{
							grilleLoad.parcours(i, j).setEstDecouvert(false);
							grilleLoad.parcours(i, j).setEstMarque(true);
						}

					}
				}	
			}

			// on parcours une deuxieme fois pour refaire les liens
			for (int i = 0; i < hauteur; i++)
			{
				for (int j = 0; j < largeur; j++)
				{
					grilleLoad.parcours(i, j).ajouterVoisine(Direction.DROITE, parcours(i, j + 1));
					grilleLoad.parcours(i, j).ajouterVoisine(Direction.GAUCHE, parcours(i, j - 1));

					grilleLoad.parcours(i, j).ajouterVoisine(Direction.HAUT, parcours(i - 1, j));
					grilleLoad.parcours(i, j).ajouterVoisine(Direction.BAS, parcours(i + 1, j));

					grilleLoad.parcours(i, j).ajouterVoisine(Direction.HAUTDROITE, parcours(i - 1, j + 1));
					grilleLoad.parcours(i, j).ajouterVoisine(Direction.HAUTGAUCHE, parcours(i - 1, j - 1));

					grilleLoad.parcours(i, j).ajouterVoisine(Direction.BASDROITE, parcours(i + 1, j + 1));
					grilleLoad.parcours(i, j).ajouterVoisine(Direction.BASGAUCHE, parcours(i + 1, j - 1));
				}
			}
			return grilleLoad;
		}
		catch (IOException e)
		{
			System.out.println("Erreur dans la lecture du fichier : " + e.getMessage());
			return null;
		}
	}
	
	// les getteurs setteurs
	public int getHauteur()
	{
		return this.hauteur;
	}

	public int getLargeur()
	{
		return this.largeur;
	}
}
