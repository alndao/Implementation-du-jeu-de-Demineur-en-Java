public class Jouer
{
	private boolean fini;
	private boolean gagne;

	private Grille grille;

	public Jouer(int h, int l, int p)
	{
		this.fini = false;
		this.gagne = false;
		this.grille = new Grille(h, l, p);
		this.grille.initGrille();
	}

	public void aGagne()
	{
		int nbBombe = 0;
		int nbNonDecouvert = 0;
		
		for (int i = 0; i < this.grille.getHauteur(); i++)
		{
			for (int j = 0; j < this.grille.getLargeur(); j++)
			{
				if (this.grille.parcours(i, j).getEstMine())

						nbBombe++;

				if (!this.grille.parcours(i, j).getEstDecouvert())

						nbNonDecouvert++;
			}	
		}	

		if (nbBombe == nbNonDecouvert)
		{
			this.fini = true;
			this.gagne = true;
		}
	}

	public void aPerdu()
	{
		for (int i = 0; i < this.grille.getHauteur(); i++)
		{
			for (int j = 0; j < this.grille.getLargeur(); j++)
			{
				if (this.grille.parcours(i, j).getEstMine() && this.grille.parcours(i,j).getEstDecouvert())
				{
					this.fini = true;
					this.gagne = false;
				}
						
			}
		}	

	}

	public void jouerPartie(int choix, int x, int y)
	{
		if (choix == 1)
		{
			if (this.grille.getHauteur() > x && this.grille.getLargeur() > y)
			{
				this.grille.parcours(x,y).uncover();
			}
		}

		else if (choix == 2)
		{
			if (this.grille.getHauteur() > x && this.grille.getLargeur() > y && !this.grille.parcours(x,y).getEstDecouvert())
			{
				this.grille.parcours(x,y).setEstMarque(true);
			}
		}
		
		this.aPerdu();
		this.aGagne();
		
	}

	// les getteurs et les setteurs
	public boolean getFini()
	{
		return this.fini;
	}
	
	public void setFini(boolean bool)
	{
		this.fini = bool;
	}


	public boolean getGagne()
	{
		return this.gagne;
	}

	public Grille getGrille()
	{
		return this.grille;
	}
}
